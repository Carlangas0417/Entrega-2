import App.view as view


# Main function
def main():
    view.main()


# Main function call to run the program
if __name__ == '__main__':
    main()
    